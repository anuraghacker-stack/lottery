from datetime import datetime
import sqlite3

import aiohttp
from aiogram import Bot, Dispatcher, types
# from aiogram.filters import Command
import asyncio
import random
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from aiocryptopay import AioCryptoPay, Networks
import re
from datetime import datetime
import sqlite3
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, CallbackQuery
from aiogram.utils import executor
import datetime
import os
from PIL import Image, ImageDraw, ImageFont

from datetime import *
from aiogram.utils.exceptions import ChatNotFound, BadRequest
import logging

crypto = AioCryptoPay(token='219009:AAVWvsqC6tdevxzFNwgG04P8nxYOgZMGoPr', network=Networks.MAIN_NET)
from datetime import datetime, timedelta
from asyncio import sleep, create_task

# Токен вашего бота
BOT_TOKEN = "6343808870:AAHuTwbibucp--b0zrlb3hijTAs_OoFq1nU"

# Имя файла базы данных SQLite
DATABASE_FILE = "users.db"

# Идентификатор администратора
ADMIN_ID = 1878928932

# Идентификатор группового чата
GROUP_CHAT_ID = -1001921736262

# Создаем подключение к базе данных
conn = sqlite3.connect(DATABASE_FILE)
cursor = conn.cursor()

# Создаем таблицу для хранения информации о пользователях, если ее еще нет
cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY, 
        name TEXT, 
        username TEXT, 
        balance REAL DEFAULT 0, 
        registration_date TEXT,
        refovod INTEGER,
        ref_count INTEGER DEFAULT 0,
        ref_earn INTEGER DEFAULT 0
    )
''')

conn.commit()

# Создаем подключение к базе данных "games.db"
conn_games = sqlite3.connect('games.db')
cursor_games = conn_games.cursor()

# Создание таблицы games, если она не существует
cursor_games.execute('''
    CREATE TABLE IF NOT EXISTS games (
        game_number INTEGER PRIMARY KEY AUTOINCREMENT,
        start_date TEXT,
        bank REAL,
        players INTEGER,
        tickets_bought INTEGER,
        message_id INTEGER
    )
''')
conn_games.commit()

conn_games = sqlite3.connect('games.db')
cursor_games = conn_games.cursor()

# Добавление столбца game_number, если его нет
try:
    cursor_games.execute('''
        ALTER TABLE games ADD COLUMN game_number INTEGER PRIMARY KEY AUTOINCREMENT
    ''')
    conn_games.commit()
except sqlite3.OperationalError:
    pass  # Если столбец уже существует, просто продолжаем

# Инициализируем бота и диспетчер
storage = MemoryStorage()
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot=bot, storage=storage)


class TopUpStates(StatesGroup):
    waiting_for_amount = State()
    waiting_for_currency = State()


# dp.middleware.setup(LoggingMiddleware())


# Определим функцию для получения номера следующей игры
def get_next_game_number():
    cursor_games.execute("SELECT MAX(game_number) FROM games")
    max_game_number = cursor_games.fetchone()[0]
    if max_game_number is None:
        return 1
    else:
        return max_game_number + 1


# Функция для получения текущего курса USD к RUB
async def get_usd_to_rub_rate():
    async with aiohttp.ClientSession() as session:
        async with session.get('https://api.exchangerate-api.com/v4/latest/USD') as resp:
            data = await resp.json()
            return data['rates']['RUB']


@dp.message_handler(commands=['start'])
async def start(message: types.Message):
    user_id = message.from_user.id
    referral_link = f"https://t.me/fdkgjdfklgfbot?start={user_id}"
    args = message.get_args()
    inviter_id = None

    if args.isdigit():
        inviter_id = int(args)

    if message.chat.type == 'private':
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()

        if not user:
            if inviter_id and inviter_id != user_id:
                cursor.execute("SELECT * FROM users WHERE id = ?", (inviter_id,))
                inviter = cursor.fetchone()

                if inviter:
                    cursor.execute(
                        "INSERT INTO users (id, name, username, registration_date, refovod) VALUES (?, ?, ?, ?, ?)",
                        (user_id, message.from_user.first_name, message.from_user.username,
                         datetime.now().strftime("%Y-%m-%d %H:%M:%S"), inviter_id))
                    cursor.execute("UPDATE users SET ref_count = ref_count + 1 WHERE id = ?", (inviter_id,))
                    conn.commit()

                    # Отправляем сообщение пригласившему
                    cursor.execute("SELECT ref_count, ref_earn FROM users WHERE id = ?", (inviter_id,))
                    ref_count, ref_earn = cursor.fetchone()
                    await bot.send_message(inviter_id,
                                           f"У вас новый реферал\nID: {user_id}\nВы пригласили уже: {ref_count} рефералов\n"
                                           f"Заработано с рефералов: {ref_earn:.2f} USD")
                    user_id = user[0]
                    balance = user[3]
                    ref_count = user[6]
                    ref_earn = user[7]

                    wallet_button = InlineKeyboardButton("💰 Кошелёк", callback_data='wallet')
                    markup = InlineKeyboardMarkup().add(wallet_button)

                    usd_to_rub_rate = await get_usd_to_rub_rate()
                    balance_rub = balance * usd_to_rub_rate
                    await message.answer(
                        f"<b>👋🏻 Привет, {message.from_user.first_name}</b>\n\n<b>🔎 ID:</b> <code>{user_id}</code>\n"
                        f"<b>💰 Баланс:</b> {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n<b>Ваш пригласитель:</b> {inviter_id}.\n<b>🔗 Ваша реферальная ссылка:</b> {referral_link}"
                        f"\n<b>👤 Всего рефералов:</b> {ref_count}\n<b>🤑 Заработано с рефералов:</b> {ref_earn:.2f} USD",
                        reply_markup=markup, parse_mode=types.ParseMode.HTML)
                else:
                    cursor.execute("INSERT INTO users (id, name, username, registration_date) VALUES (?, ?, ?, ?)",
                                   (user_id, message.from_user.first_name, message.from_user.username,
                                    datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                    conn.commit()
                    await message.answer("Добро пожаловать! Вы зарегистрированы в системе, но пригласитель не найден.")
            else:
                cursor.execute("INSERT INTO users (id, name, username, registration_date) VALUES (?, ?, ?, ?)",
                               (user_id, message.from_user.first_name, message.from_user.username,
                                datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
                conn.commit()
                await message.answer("Добро пожаловать! Вы зарегистрированы в системе.")

            admin_message = (f"Новый пользователь!\nName: {message.from_user.first_name}\n"
                             f"ID: {message.from_user.id}\nUsername: @{message.from_user.username}")
            await bot.send_message(ADMIN_ID, admin_message)
        else:
            user_id = user[0]
            balance = user[3]
            ref_count = user[6]
            ref_earn = user[7]

            wallet_button = InlineKeyboardButton("💰 Кошелёк", callback_data='wallet')
            markup = InlineKeyboardMarkup().add(wallet_button)

            usd_to_rub_rate = await get_usd_to_rub_rate()
            balance_rub = balance * usd_to_rub_rate

            await message.answer(
                f"<b>👋🏻 Привет, {message.from_user.first_name}</b>\n\n<b>🔎 ID:</b> <code>{user_id}</code>\n"
                f"<b>💰 Баланс:</b> {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n<b>🔗 Ваша реферальная ссылка:</b> {referral_link}"
                f"\n<b>👤 Всего рефералов:</b> {ref_count}\n<b>🤑 Заработано с рефералов:</b> {ref_earn:.2f} USD",
                reply_markup=markup, parse_mode=types.ParseMode.HTML)
    else:
        pass

    await bot.send_message(chat_id=GROUP_CHAT_ID, text="Максим красавчик", reply_to_message_id=98)


@dp.callback_query_handler(lambda c: c.data == 'wallet')
async def process_wallet(callback_query: CallbackQuery):
    # Получаем баланс пользователя из базы данных
    cursor.execute("SELECT * FROM users WHERE id = ?", (callback_query.from_user.id,))
    user = cursor.fetchone()
    balance = user[3]

    usd_to_rub_rate = await get_usd_to_rub_rate()
    balance_rub = balance * usd_to_rub_rate

    # Создаем кнопки
    top_up_button = InlineKeyboardButton("Пополнить", callback_data='top_up')
    withdraw_button = InlineKeyboardButton("Вывести", callback_data='withdraw')
    back_button = InlineKeyboardButton("Назад", callback_data='back')
    markup = InlineKeyboardMarkup().add(top_up_button, withdraw_button).add(back_button)

    user_id = callback_query.from_user.id
    referral_link = f"https://t.me/fdkgjdfklgfbot?start={user_id}"

    await bot.edit_message_text(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id,
                                text=f"Кошелёк\n<b>🔎 ID:</b> <code>{callback_query.from_user.id}</code>\nБаланс: {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n<b>🔗 Ваша реферальная ссылка:</b> {referral_link}",
                                reply_markup=markup, parse_mode=types.ParseMode.HTML)


@dp.callback_query_handler(lambda c: c.data == 'top_up')
async def process_top_up(callback_query: CallbackQuery):
    # Редактируем сообщение и добавляем кнопки для выбора валюты
    rub_button = InlineKeyboardButton("RUB", callback_data='top_up_rub')
    usd_button = InlineKeyboardButton("USD", callback_data='top_up_usd')
    back_button = InlineKeyboardButton("Назад", callback_data='back_to_wallet')
    markup = InlineKeyboardMarkup().add(rub_button, usd_button).add(back_button)

    await bot.edit_message_text(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id,
                                text="Выберите валюту:", reply_markup=markup)

    # Устанавливаем состояние ожидания выбора валюты
    await TopUpStates.waiting_for_currency.set()


@dp.callback_query_handler(lambda c: c.data == 'withdraw')
async def process_withdraw(callback_query: CallbackQuery):
    await bot.send_message(callback_query.from_user.id, "Ок")


@dp.callback_query_handler(lambda c: c.data == 'back')
async def process_back(callback_query: CallbackQuery):
    # Получаем баланс пользователя из базы данных
    cursor.execute("SELECT * FROM users WHERE id = ?", (callback_query.from_user.id,))
    user = cursor.fetchone()
    balance = user[3]

    # Создаем кнопку
    wallet_button = InlineKeyboardButton("💰 Кошелёк", callback_data='wallet')
    markup = InlineKeyboardMarkup().add(wallet_button)

    user_id = callback_query.from_user.id
    referral_link = f"https://t.me/fdkgjdfklgfbot?start={user_id}"

    usd_to_rub_rate = await get_usd_to_rub_rate()
    balance_rub = balance * usd_to_rub_rate

    await bot.edit_message_text(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id,
                                text=f"<b>👋🏻 Привет, {callback_query.from_user.first_name}</b>\n\n<b>🔎 ID:</b> <code>{callback_query.from_user.id}</code>\n<b>💰 Баланс:</b> {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n<b>🔗 Ваша реферальная ссылка:</b> {referral_link}",
                                reply_markup=markup, parse_mode=types.ParseMode.HTML)


@dp.callback_query_handler(lambda c: c.data == 'back_to_wallet', state=TopUpStates.waiting_for_currency)
async def process_back_to_wallet(callback_query: CallbackQuery, state: FSMContext):
    await state.finish()
    await process_wallet(callback_query)


@dp.callback_query_handler(lambda c: c.data in ['top_up_rub', 'top_up_usd'], state=TopUpStates.waiting_for_currency)
async def process_currency_choice(callback_query: CallbackQuery, state: FSMContext):
    # Сохраняем выбор валюты в состояние
    currency = callback_query.data.split('_')[-1].upper()
    await state.update_data(currency=currency)

    if currency == 'RUB':
        # Получаем текущий курс USD к RUB
        usd_to_rub_rate = await get_usd_to_rub_rate()
        min_amount_rub = 0.2 * usd_to_rub_rate
        min_amount_usd = 0.2
        await bot.edit_message_text(chat_id=callback_query.message.chat.id,
                                    message_id=callback_query.message.message_id,
                                    text=f"Минимальная сумма пополнения {min_amount_rub:.3f} RUB (≈{min_amount_usd:.2f} USD)\nВведите сумму в RUB:",
                                    reply_markup=InlineKeyboardMarkup().add(
                                        InlineKeyboardButton("Назад ⬅️", callback_data='cancel')))
    else:
        usd_to_rub_rate = await get_usd_to_rub_rate()
        min_amount_rub = 0.2 * usd_to_rub_rate
        min_amount_usd = 0.2
        await bot.edit_message_text(chat_id=callback_query.message.chat.id,
                                    message_id=callback_query.message.message_id,
                                    text=f"Минимальная сумма пополнения {min_amount_usd:.2f} USD (≈{min_amount_rub:.3f} RUB)\nВведите сумму в USD:",
                                    reply_markup=InlineKeyboardMarkup().add(
                                        InlineKeyboardButton("Назад ⬅️", callback_data='cancel')))

    # Устанавливаем состояние ожидания суммы пополнения
    await TopUpStates.waiting_for_amount.set()


@dp.callback_query_handler(lambda c: c.data == 'cancel', state=TopUpStates.waiting_for_amount)
async def process_cancel(callback_query: CallbackQuery, state: FSMContext):
    # Получаем баланс пользователя из базы данных
    cursor.execute("SELECT * FROM users WHERE id = ?", (callback_query.from_user.id,))
    user = cursor.fetchone()
    balance = user[3]
    wallet_button = InlineKeyboardButton("💰 Кошелёк", callback_data='wallet')
    markup = InlineKeyboardMarkup().add(wallet_button)

    # Завершаем состояние ожидания и возвращаем сообщение
    await state.finish()

    usd_to_rub_rate = await get_usd_to_rub_rate()
    balance_rub = balance * usd_to_rub_rate

    user_id = callback_query.from_user.id
    referral_link = f"https://t.me/fdkgjdfklgfbot?start={user_id}"

    await bot.edit_message_text(chat_id=callback_query.message.chat.id, message_id=callback_query.message.message_id,
                                text=f"<b>👋🏻 Привет, {callback_query.from_user.first_name}</b>\n\n<b>🔎 ID:</b> <code>{callback_query.from_user.id}</code>\n<b>💰 Баланс:</b> {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n<b>🔗 Ваша реферальная ссылка:</b> {referral_link}",
                                reply_markup=markup, parse_mode=types.ParseMode.HTML)


@dp.message_handler(state=TopUpStates.waiting_for_amount)
async def process_amount(message: types.Message, state: FSMContext):
    data = await state.get_data()
    currency = data['currency']

    try:
        amount = float(message.text)

        # Проверка на округление до десятых
        if amount * 10 != int(amount * 10):
            await message.answer("Пожалуйста, введите сумму без сотых. Например, 10, 20, 0.5, 0.2 и т.д.")
            return

        min_amount_usd = 0.2
        if currency == 'RUB':
            usd_to_rub_rate = await get_usd_to_rub_rate()
            min_amount = min_amount_usd * usd_to_rub_rate
            if amount < min_amount:
                await message.answer(f"Пожалуйста, введите сумму от {min_amount:.2f} RUB:")
                return
        else:
            if amount < min_amount_usd or amount > 1000:
                await message.answer("Пожалуйста, введите сумму от 0.2 до 1000 USD:")
                return

        # Создаем счет на оплату
        fiat_invoice = await crypto.create_invoice(amount=amount, fiat=currency, currency_type='fiat')

        cancel_button = InlineKeyboardButton("Отмена ❌", callback_data='cancel_payment')
        markup = InlineKeyboardMarkup().add(cancel_button)

        payment_message = await message.answer(f"Перейдите по ссылке для оплаты:\n{fiat_invoice.bot_invoice_url}",
                                               reply_markup=markup)

        while True:
            invoices = await crypto.get_invoices(invoice_ids=[fiat_invoice.invoice_id])
            if invoices[0].status == 'paid':
                await bot.delete_message(payment_message.chat.id, payment_message.message_id)
                await message.answer("Оплата прошла успешно!")

                # Обновляем баланс пользователя в базе данных
                cursor.execute("SELECT balance FROM users WHERE id = ?", (message.from_user.id,))
                current_balance = cursor.fetchone()[0]
                if currency == 'RUB':
                    amount_rub = amount
                    amount_usd = amount_rub / usd_to_rub_rate
                    new_balance = current_balance + amount_usd
                elif currency == 'USD':
                    amount_usd = amount
                    new_balance = current_balance + amount

                cursor.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, message.from_user.id))
                conn.commit()

                # Начисление бонуса пригласителю
                cursor.execute("SELECT refovod FROM users WHERE id = ?", (message.from_user.id,))
                refovod = cursor.fetchone()[0]
                if refovod:
                    bonus_amount = amount_usd * 0.1
                    cursor.execute("UPDATE users SET balance = balance + ?, ref_earn = ref_earn + ? WHERE id = ?",
                                   (bonus_amount, bonus_amount, refovod))
                    conn.commit()
                    await bot.send_message(refovod,
                                           f"Вам начислено {bonus_amount:.2f} USD за пополнение вашего реферала {message.from_user.id}.")

                usd_to_rub_rate = await get_usd_to_rub_rate()
                balance_rub = new_balance * usd_to_rub_rate

                await message.answer(
                    f"Вы пополнили счёт на {amount:.2f} {currency}\nВаш баланс: {new_balance:.2f}$ ({balance_rub:.2f} RUB)")
                break

            await asyncio.sleep(10)  # Проверяем статус каждые 10 секунд

        await state.finish()
    except ValueError:
        await message.answer("Пожалуйста, введите корректное число.")


# Обработчик нажатия на кнопку "Отмена ❌"
@dp.callback_query_handler(lambda c: c.data == 'cancel_payment', state=TopUpStates.waiting_for_amount)
async def cancel_payment(callback_query: CallbackQuery, state: FSMContext):
    print("Cancel button pressed")  # Отладочная информация
    await callback_query.answer("Отмена...")
    await bot.delete_message(callback_query.message.chat.id, callback_query.message.message_id)

    user_id = callback_query.from_user.id
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user = cursor.fetchone()

    if user:
        balance = user[3]  # Предположим, что баланс пользователя хранится в 4-м столбце
        ref_count = user[5]  # Предположим, что количество рефералов хранится в 6-м столбце
        ref_earn = user[6]  # Предположим, что заработано с рефералов хранится в 7-м столбце

        usd_to_rub_rate = await get_usd_to_rub_rate()
        balance_rub = balance * usd_to_rub_rate

        referral_link = f"https://t.me/fdkgjdfklgfbot?start={user_id}"
        wallet_button = InlineKeyboardButton("💰 Кошелёк", callback_data='wallet')
        markup = InlineKeyboardMarkup().add(wallet_button)

        await bot.send_message(
            chat_id=user_id,
            text=(
                f"<b>👋🏻 Привет, {callback_query.from_user.first_name}</b>\n\n"
                f"<b>🔎 ID:</b> <code>{user_id}</code>\n"
                f"<b>💰 Баланс:</b> {balance:.2f}$ ({balance_rub:.2f} RUB)\n\n"
                f"<b>🔗 Ваша реферальная ссылка:</b> {referral_link}\n"
                f"<b>👤 Всего рефералов:</b> {ref_count}\n"
                f"<b>🤑 Заработано с рефералов:</b> {ref_earn:.2f} USD"
            ),
            reply_markup=markup,
            parse_mode=types.ParseMode.HTML
        )

    await state.finish()


def get_all_users():
    with sqlite3.connect(DATABASE_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users")
        return [row[0] for row in cursor.fetchall()]


admin_state = {}
start_datetime = {}

game_started = False

# В начале скрипта
current_game_number = None
keyboard = None


# Функция для генерации изображения
def generate_image(game_number, text, date_text):
    font_size = 100
    date_font_size = 40
    width, height = 1280, 720  # Изменен размер изображения на 1920x1080
    image = Image.new('RGB', (width, height), color=(73, 109, 137))

    # Указание пути к шрифту
    current_dir = os.path.dirname(os.path.abspath(__file__))
    font_path = os.path.join(current_dir, 'Font', 'OnestBold1602-hint.ttf')

    try:
        font = ImageFont.truetype(font_path, font_size)
        date_font = ImageFont.truetype(font_path, date_font_size)
    except IOError:
        logging.error(f"Font not found at path: {font_path}")
        raise Exception("Font not found. Please provide a valid path to a .ttf font file.")

    draw = ImageDraw.Draw(image)

    # Рассчитываем размер текста "Лотерея #current_game_number"
    game_number_text = f"Лотерея #{game_number}"
    game_number_text_bbox = draw.textbbox((0, 0), game_number_text, font=font)
    game_number_text_width = game_number_text_bbox[2] - game_number_text_bbox[0]
    game_number_text_height = game_number_text_bbox[3] - game_number_text_bbox[1]

    # Рисуем текст "Лотерея #current_game_number" сверху над основным текстом
    game_number_text_position = ((width - game_number_text_width) / 2, (height - game_number_text_height) / 2 - 50)
    draw.text(game_number_text_position, game_number_text, font=font, fill="white")

    # Рисуем основной текст "Игра началась!"
    text_bbox = draw.textbbox((0, 0), text, font=font)
    text_width = text_bbox[2] - text_bbox[0]
    text_height = text_bbox[3] - text_bbox[1]
    text_position = ((width - text_width) / 2, (height - text_height) / 2 + 50)
    draw.text(text_position, text, font=font, fill="white")

    # Рисуем дату
    date_bbox = draw.textbbox((0, 0), date_text, font=date_font)
    date_text_width = date_bbox[2] - date_bbox[0]
    date_text_height = date_bbox[3] - date_bbox[1]
    date_position = ((width - date_text_width) / 2, height - date_text_height - 30)  # Поднимаем дату на 30 пикселей
    draw.text(date_position, date_text, font=date_font, fill="white")

    return image


# Команда /play
@dp.message_handler(commands=['play'])
async def play_lottery(message: types.Message):
    global admin_state, current_game_number, keyboard
    if message.chat.type == 'private' and message.from_user.id == ADMIN_ID:
        try:
            # Создаем новую игру
            new_game_number = get_next_game_number()
            current_game_number = new_game_number  # Обновляем глобальную переменную
            bank = 0
            buy_ticket_button = InlineKeyboardButton("Купить билет", callback_data="buy_ticket")
            keyboard = InlineKeyboardMarkup().add(buy_ticket_button)
            start_game_button = InlineKeyboardButton("Начать игру", callback_data="start_game")
            admin_keyboard = InlineKeyboardMarkup().add(start_game_button)

            current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Исправлено на %S
            date_text = datetime.now().strftime("%d.%m.%y")

            cursor_games.execute(
                "INSERT INTO games (game_number, start_date, bank, players, tickets_bought) VALUES (?, ?, ?, ?, ?)",
                (new_game_number, current_datetime, bank, 0, 0))
            conn_games.commit()

            # Генерация изображения
            image = generate_image(new_game_number, "Игра началась!", date_text)
            image_path = 'announcement_image.png'
            image.save(image_path)

            # Отправляем изображение в групповой чат
            with open(image_path, 'rb') as photo:
                announcement_message = await bot.send_photo(GROUP_CHAT_ID, photo,
                                                            caption=f"Лотерея #{new_game_number} началась!\nБанк: ${bank}\nПриобрести билеты можно лично в диалоге с ботом.",
                                                            reply_to_message_id=317)
            announcement_message_id = announcement_message.message_id

            # Получаем список пользователей и отправляем каждому сообщение о начале игры
            users = get_all_users()
            user_messages = []
            for user_id in users:
                try:
                    user_message = await bot.send_message(user_id,
                                                          f"Лотерея #{new_game_number} началась!\nБанк: ${bank}\nПокупайте билеты в боте",
                                                          reply_markup=keyboard)
                    cursor_games.execute(
                        "INSERT INTO user_messages (user_id, game_number, message_id) VALUES (?, ?, ?)",
                        (user_id, new_game_number, user_message.message_id))
                    conn_games.commit()
                    user_messages.append((user_id, user_message.message_id))
                except Exception as e:
                    logging.error(f"Не удалось отправить сообщение пользователю {user_id}: {e}")

            # Обновляем сообщение в групповом чате и устанавливаем сообщения пользователям
            cursor_games.execute("UPDATE games SET message_id = ? WHERE game_number = ?",
                                 (announcement_message_id, new_game_number))
            conn_games.commit()

            # Устанавливаем состояние администратора в 'game_started'
            admin_state[message.from_user.id] = 'game_started'

            await message.reply(f"Игра лотереи #{new_game_number} запущена успешно.", reply_markup=admin_keyboard)

        except Exception as e:
            logging.error(f"Ошибка при запуске игры: {e}")
    else:
        await message.reply("Извините, команда доступна только администратору в личных сообщениях.")


# Обработчик нажатия на кнопку "Купить билет"
@dp.callback_query_handler(lambda query: query.data == 'buy_ticket')
async def buy_ticket(callback_query: types.CallbackQuery):
    user = callback_query.from_user
    user_id = user.id

    cancel_button = InlineKeyboardButton("Отмена", callback_data="cancel_buying")
    keyboard = InlineKeyboardMarkup().add(cancel_button)

    await bot.send_message(user_id, "Сколько билетов вы хотите купить?", reply_markup=keyboard)


# Обработчик для получения количества билетов от пользователя
@dp.message_handler(lambda message: message.chat.type == types.ChatType.PRIVATE and message.text.isdigit())
async def process_buy_ticket(message: types.Message):
    global current_game_number
    user_id = message.from_user.id
    num_tickets = int(message.text)

    cursor_games.execute("SELECT * FROM games WHERE game_number = (SELECT MAX(game_number) FROM games)")
    game_data = cursor_games.fetchone()

    if not game_data:
        await message.reply("Сейчас нет активных игр. Пожалуйста, дождитесь запуска новой игры.")
        return

    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    user_data = cursor.fetchone()

    if not user_data:
        await message.reply("Ошибка: пользователь не найден в базе данных.")
        return

    balance = user_data[3]
    ticket_price = num_tickets * 1
    commission = ticket_price * 0.1
    net_price = ticket_price - commission

    if num_tickets <= 0:
        await message.reply("Введите положительное число билетов.")
        return
    if ticket_price > balance:
        await message.reply("Недостаточно средств на балансе.")
        return

    new_balance = balance - ticket_price

    cursor.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, user_id))
    conn.commit()

    cursor_games.execute(
        "UPDATE games SET bank = bank + ?, tickets_bought = tickets_bought + ? WHERE game_number = (SELECT MAX(game_number) FROM games)",
        (net_price, num_tickets))
    conn_games.commit()

    cursor_games.execute(
        "SELECT bank, message_id, players, tickets_bought FROM games WHERE game_number = (SELECT MAX(game_number) FROM games)")
    game_data = cursor_games.fetchone()
    updated_bank = game_data[0]
    announcement_message_id = game_data[1]
    players = game_data[2]
    tickets_bought = game_data[3]

    # Проверка, покупает ли пользователь билет впервые в этой игре
    cursor_games.execute(
        "SELECT COUNT(*) FROM user_messages WHERE user_id = ? AND game_number = (SELECT MAX(game_number) FROM games)",
        (user_id,))
    if cursor_games.fetchone()[0] == 0:
        players += 1
        cursor_games.execute(
            "UPDATE games SET players = ? WHERE game_number = (SELECT MAX(game_number) FROM games)",
            (players,))
        conn_games.commit()

    await message.reply(f"Вы купили {num_tickets} билетов 🔥")

    user_name = message.from_user.first_name
    amount = num_tickets * 1
    await bot.send_message(GROUP_CHAT_ID,
                           f"🛒 <b>{user_name}</b> купил {num_tickets} билетов\n🏦 <b>Банк</b>: {updated_bank}$",
                           reply_to_message_id=317, parse_mode=types.ParseMode.HTML)

    # Обновление сообщений у каждого пользователя
    cursor_games.execute("SELECT user_id, message_id FROM user_messages WHERE game_number = ?",
                         (current_game_number,))
    user_messages = cursor_games.fetchall()

    for user_id, message_id in user_messages:
        try:
            await bot.edit_message_text(chat_id=user_id, message_id=message_id,
                                        text=f"Лотерея #{current_game_number} началась!\nБанк: ${updated_bank}\nПокупайте билеты в боте",
                                        reply_markup=keyboard)
        except Exception as e:
            logging.error(f"Не удалось обновить сообщение для пользователя {user_id}: {e}")

    try:
        await bot.edit_message_caption(chat_id=GROUP_CHAT_ID, message_id=announcement_message_id,
                                       caption=f"Лотерея #{current_game_number} началась!\nБанк: ${updated_bank}\nПокупайте билеты в боте")
    except Exception as e:
        logging.error(f"Не удалось обновить сообщение в групповом чате: {e}")


# Обработчик нажатия на кнопку "Отмена"
@dp.callback_query_handler(lambda query: query.data == 'cancel_buying')
async def cancel_buying(callback_query: types.CallbackQuery):
    chat_id = callback_query.message.chat.id
    message_id = callback_query.message.message_id
    await bot.delete_message(chat_id, message_id)


# Обработчик нажатия на кнопку "Начать игру"
@dp.callback_query_handler(lambda query: query.data == 'start_game')
async def start_game(callback_query: types.CallbackQuery):
    global current_game_number
    user_id = callback_query.from_user.id

    if user_id != ADMIN_ID:
        await bot.answer_callback_query(callback_query.id, "Эта кнопка доступна только администратору.")
        return

    cursor_games.execute("SELECT bank, message_id FROM games WHERE game_number = ?", (current_game_number,))
    game_data = cursor_games.fetchone()
    updated_bank = game_data[0]
    announcement_message_id = game_data[1]

    # Обновление сообщений у каждого пользователя
    cursor_games.execute("SELECT user_id, message_id FROM user_messages WHERE game_number = ?",
                         (current_game_number,))
    user_messages = cursor_games.fetchall()
    await bot.send_message(GROUP_CHAT_ID,
                           f"Лотерея #{current_game_number} началась\nБанк: {updated_bank}$",
                           reply_to_message_id=317)

    for user_id, message_id in user_messages:
        try:
            await bot.edit_message_text(chat_id=user_id, message_id=message_id,
                                        text=f"Игра лотереи #{current_game_number} началась!\nБанк: ${updated_bank}\nИгра начинается!")
        except Exception as e:
            logging.error(f"Не удалось обновить сообщение для пользователя {user_id}: {e}")

    try:
        await bot.edit_message_caption(chat_id=GROUP_CHAT_ID, message_id=announcement_message_id,
                                       caption=f"Игра лотереи #{current_game_number} началась!\nБанк: ${updated_bank}\nИгра начинается!")
    except Exception as e:
        logging.error(f"Не удалось обновить сообщение в групповом чате: {e}")

    await bot.answer_callback_query(callback_query.id, "Игра началась!")


@dp.message_handler(commands=['balance'])
async def add_balance(message: types.Message):
    # Проверяем, является ли отправитель администратором
    if message.from_user.id == ADMIN_ID:
        # Проверяем, правильно ли введены аргументы команды
        try:
            user_id, amount = map(int, message.get_args().split())
        except (ValueError, TypeError):
            await message.answer(
                "Пожалуйста, укажите ID пользователя и сумму для начисления баланса в формате: /balance <user_id> <amount>")
            return

        # Проверяем, существует ли пользователь с указанным ID в базе данных
        cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        if user:
            # Обновляем баланс пользователя
            new_balance = user[3] + amount
            cursor.execute("UPDATE users SET balance = ? WHERE id = ?", (new_balance, user_id))
            conn.commit()
            await message.answer(f"Баланс пользователя с ID {user_id} успешно обновлен. Новый баланс: {new_balance}")
            await bot.send_message(user_id, f"На ваш баланс добавили {amount}\nНовый баланс: {new_balance}")
        else:
            await message.answer("Пользователь с указанным ID не найден в базе данных.")
    else:
        await message.answer("У вас нет прав на выполнение этой команды.")


async def main():
    await dp.start_polling(bot)


# Запуск бота
if __name__ == '__main__':
    from aiogram.contrib.middlewares.logging import LoggingMiddleware

    dp.middleware.setup(LoggingMiddleware())
    executor.start_polling(dp, skip_updates=True)
